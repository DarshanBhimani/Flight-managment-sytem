#include <stdio.h>
#include<stdlib.h>
#include<windows.h>
void about(){
    printf("<<<<<<<<<<<ABOUT US>>>>>>>>>>>>\n\n");
    printf("The height of skies was first touched by our airline in 2020. \nSince then,High Fly is the world's leading airline with 4 biggest airplanes.\nWe are at the customers high service in cuisine, comfort and care.\nSo make a plan and fly high with High Fly...");
    getch();
    system("cls");
}
